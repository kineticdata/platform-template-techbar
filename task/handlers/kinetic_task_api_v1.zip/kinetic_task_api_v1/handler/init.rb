# Require the dependencies file to load the vendor libraries
require File.expand_path(File.join(File.dirname(__FILE__), "dependencies"))
require 'base64'
require 'digest'
require 'uri'

class KineticTaskApiV1
  # ==== Parameters
  # * +input+ - The String of Xml that was built by evaluating the node.xml handler template.
  def initialize(input)
    # Set the input document attribute
    @input_document = REXML::Document.new(input)

    # Retrieve all of the handler info values and store them in a hash variable named @info_values.
    @info_values = {}
    REXML::XPath.each(@input_document, "/handler/infos/info") do |item|
      @info_values[item.attributes["name"]] = item.text.to_s.strip
    end

    # Retrieve all of the handler parameters and store them in a hash variable named @parameters.
    @parameters = {}
    REXML::XPath.each(@input_document, "/handler/parameters/parameter") do |item|
      @parameters[item.attributes["name"]] = item.text.to_s.strip
    end

    @debug_logging_enabled = ["yes","true"].include?(@info_values['enable_debug_logging'].downcase)
    @error_handling = @parameters["error_handling"]

    @api_location = @info_values["api_location"]
    @api_location.chomp!("/")
    @api_username = @info_values["api_username"]
    @api_password = @info_values["api_password"]
    @api_access_key_identifier = @info_values['api_access_key_identifier']
    @api_access_key_secret = @info_values['api_access_key_secret']

    @body = @parameters["body"].to_s.empty? ? {} : JSON.parse(@parameters["body"])
    @method = (@parameters["method"] || :get).downcase.to_sym
    @path = @parameters["path"]
    @path = "/#{@path}" if !@path.start_with?("/")

    @accept = :json
    @content_type = :json
  end

  def execute
    # Initialize return data
    error_message = nil
    response_code = nil

    begin
      uri = URI("#{@api_location}#{@path}")
      api_route = sanitized_api_route(uri)
      payload = @body.to_json

      headers = {
        :accept => @accept,
        :content_type => @content_type
      }

      if !@api_access_key_identifier.empty? && !@api_access_key_secret.empty?
        puts "Adding X-Kinetic-SignatureKey header: #{@api_access_key_identifier}" if @debug_logging_enabled
        headers.merge!({ 'X-Kinetic-SignatureKey' => @api_access_key_identifier })

        signature = sign(@api_access_key_secret, payload)
        puts "Adding X-Kinetic-Signature header: #{signature}" if @debug_logging_enabled
        headers.merge!({ 'X-Kinetic-Signature' => signature })
      end
    
      puts "API ROUTE: #{@method.to_s.upcase} #{api_route}" if @debug_logging_enabled
      puts "HEADERS: #{headers.inspect}" if @debug_logging_enabled
      puts "BODY: \n #{payload}" if @debug_logging_enabled

      response = RestClient::Request.execute \
        method: @method, \
        url: api_route, \
        user: @api_username, \
        password: @api_password, \
        payload: payload, \
        headers: headers
      response_code = response.code
    rescue RestClient::Exception => e
      if @error_handling
        begin
          # Attempt to parse the JSON error message. Re-throw the original error if the
          # parsing fails
          error = JSON.parse(e.response)
          error_message = error["message"] || error["error"]
          response_code = e.response.code
        rescue Exception
          puts "There was an error parsing the JSON error response" if @debug_logging_enabled
          error_message = e.inspect
        end
      else
        raise
      end
    end

    # Return (and escape) the results that were defined in the node.xml
    <<-RESULTS
    <results>
      <result name="Response Body">#{escape(response.nil? ? {} : response.body)}</result>
      <result name="Response Code">#{escape(response_code)}</result>
      <result name="Handler Error Message">#{escape(error_message)}</result>
    </results>
    RESULTS
  end

  ##############################################################################
  # General handler utility functions
  ##############################################################################

  # This is a template method that is used to escape results values (returned in
  # execute) that would cause the XML to be invalid.  This method is not
  # necessary if values do not contain character that have special meaning in
  # XML (&, ", <, and >), however it is a good practice to use it for all return
  # variable results in case the value could include one of those characters in
  # the future.  This method can be copied and reused between handlers.
  def escape(string)
    # Globally replace characters based on the ESCAPE_CHARACTERS constant
    string.to_s.gsub(/[&"><]/) { |special| ESCAPE_CHARACTERS[special] } if string
  end
  # This is a ruby constant that is used by the escape method
  ESCAPE_CHARACTERS = {'&'=>'&amp;', '>'=>'&gt;', '<'=>'&lt;', '"' => '&quot;'}


  private

  def sign(secret, body)
    sha1 = Digest::SHA1.digest(secret + body)
    Base64.urlsafe_encode64(sha1, padding: false)
  end
  
  def sanitized_api_route(uri)
    api_route = nil
    # build the route up to the query parameters
    if (uri.scheme == "http" && uri.port == 80) || (uri.scheme == "https" && uri.port == 443)
      api_route = "#{uri.scheme}://#{uri.host}#{uri.path}"
    else
      api_route = "#{uri.scheme}://#{uri.host}:#{uri.port.to_s}#{uri.path}"
    end
    puts "API ROUTE WITHOUT QUERY: #{api_route}" if @debug_logging_enabled
    # add query parameters that have a value
    parse_nested_query(uri.query).each do |key,value|
      puts "API ROUTE QUERY PARAM - KEY: #{key.to_s}, VALUE: #{value.to_s}" if @debug_logging_enabled
      if !value.to_s.strip.empty?
        key = ERB::Util.url_encode(key)
        value = ERB::Util.url_encode(value)
        if api_route.include?('?')
          api_route << "&#{key}=#{value}"
        else
          api_route << "?#{key}=#{value}"
        end
      end
    end
    puts "API ROUTE WITH QUERY: #{api_route}" if @debug_logging_enabled
    api_route
  end

  # The following methods were all borrowed from Rack::Utils

  def normalize_params(params, name, v = nil)
    name =~ %r([\[\]]*([^\[\]]+)\]*)
    k = $1 || ''
    after = $' || ''

    return if k.empty?

    if after == ""
      params[k] = v
    elsif after == "[]"
      params[k] ||= []
      raise TypeError unless params[k].is_a?(Array)
      params[k] << v
    elsif after =~ %r(^\[\]\[([^\[\]]+)\]$) || after =~ %r(^\[\](.+)$)
      child_key = $1
      params[k] ||= []
      raise TypeError unless params[k].is_a?(Array)
      if params[k].last.is_a?(Hash) && !params[k].last.key?(child_key)
        normalize_params(params[k].last, child_key, v)
      else
        params[k] << normalize_params({}, child_key, v)
      end
    else
      params[k] ||= {}
      params[k] = normalize_params(params[k], after, v)
    end

    return params
  end
    
  def parse_nested_query(qs, d='&;')
    params = {}

    (qs || '').split(/[#{d}] */n).each do |p|
      puts "API ROUTE QUERY PARAMETER PAIR: #{p}" if @debug_logging_enabled
        k, v = unescape(p).split('=', 2)
      normalize_params(params, k, v)
    end
    return params
  end

  def unescape(s)
    s.tr('+', ' ').gsub(/((?:%[0-9a-fA-F]{2})+)/n){
      [$1.delete('%')].pack('H*')
    }
  end

end
