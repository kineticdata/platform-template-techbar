{
  'info' => {
    'enable_debug_logging' => 'Yes'
  },
  'parameters' => {
    'start' => '2017-05-17 14:00:00 UTC',
    'recurrence_type' => 'Yearly',
    'timing' => 'Relative',
    'interval' => '1',
    'months' => 'January , April , July',
    'days_of_month' => '',
    'weekdays' => 'Monday',
    'sunday_index' => '',
    'monday_index' => 'All',
    'tuesday_index' => '',
    'wednesday_index' => '',
    'thursday_index' => '',
    'friday_index' => '',
    'saturday_index' => ''
  }
}