{
  'info' => {
    'enable_debug_logging' => 'Yes'
  },
  'parameters' => {
    'start' => '2017-05-17 14:00:00 UTC',
    'recurrence_type' => 'Daily',
    'timing' => '',
    'interval' => '4',
    'months' => '',
    'days_of_month' => '',
    'weekdays' => '',
    'sunday_index' => '',
    'monday_index' => '',
    'tuesday_index' => '',
    'wednesday_index' => '',
    'thursday_index' => '',
    'friday_index' => '',
    'saturday_index' => ''
  }
}