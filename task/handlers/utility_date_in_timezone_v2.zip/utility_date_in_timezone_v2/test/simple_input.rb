{
  'info' => {
    'enable_debug_logging'=>'yes'
  },
  'parameters' => {
    'timezone' => 'America/Chicago',
    'timestamp' => '2019-01-16T22:45:00Z',
    'direction' => 'To UTC'
  }
}
