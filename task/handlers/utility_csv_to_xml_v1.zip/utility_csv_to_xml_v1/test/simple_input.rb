{
  'parameters' => {
    'csv' => "Red, Orange , Yellow, Green , Blue, Indigo, Violet, Pink, Purple, Teal"
  }
}