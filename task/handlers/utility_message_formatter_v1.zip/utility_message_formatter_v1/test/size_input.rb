{
  'info' => {
    'enable_debug_logging' => 'Yes'
  },
  'parameters' => {
    'error_handling' => 'Raise Error',
    'input' => "<% b = 12345678 %>Size: <%= Humanize::Byte.new(b).human.to_s(decimal_digits: 2) %>"
  }
}
