{
  'info' => {
    'enable_debug_logging' => 'Yes'
  },
  'parameters' => {
    'error_handling' => 'Raise Error',
    'input' => "<% b = '8739273' %>Size: <%= Kinetic::Commons.human_bytes(b) %>"
  }
}
