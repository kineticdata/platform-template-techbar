{
  'info' => {
    'enable_debug_logging' => 'Yes'
  },
  'parameters' => {
    'error_handling' => 'Raise Error',
    'input' => "<% n = Time.now %>Now: <%= ::Kinetic::Commons.escape(n) %>"
  }
}
