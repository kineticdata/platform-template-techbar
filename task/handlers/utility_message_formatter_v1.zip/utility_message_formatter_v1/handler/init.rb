# -*- coding: utf-8 -*-
#

# Require the dependencies
require File.expand_path(File.join(File.dirname(__FILE__), "dependencies"))

require 'erb'

class UtilityMessageFormatterV1

  def initialize(input)
    @input_document = REXML::Document.new(input)

    # Store the info values in a Hash of info names to values.
    @info_values = {}
    REXML::XPath.each(@input_document,"/handler/infos/info") { |item|
      @info_values[item.attributes['name']] = item.text
    }

    # Store parameters values in a Hash of parameter names to values.
    @parameters = {}
    REXML::XPath.match(@input_document, '/handler/parameters/parameter').each do |node|
      @parameters[node.attribute('name').value] = node.text.to_s
    end
  end

  def execute
    debugging = @info_values['enable_debug_logging'] == 'Yes'

    begin
      output = ERB.new(@parameters['input']).result
      error_message  = nil
      puts("Output: #{output}") if debugging
    rescue => exception
      if @parameters["error_handling"] == 'Raise Error'
        puts("Exception: #{exception.inspect}") if debugging
        raise exception 
      else
        output = nil
        error_message = exception.inspect
        puts("Handler Error Message: #{error_message}") if debugging
      end
    end

    # Return the results
    return <<-RESULTS
    <results>
      <result name="Handler Error Message">#{escape(error_message)}</result>
      <result name="Output">#{escape(output)}</result>
    </results>
    RESULTS
  end


  ##############################################################################
  # General handler utility functions
  ##############################################################################

  # This is a template method that is used to escape results values (returned in
  # execute) that would cause the XML to be invalid.  This method is not
  # necessary if values do not contain character that have special meaning in
  # XML (&, ", <, and >), however it is a good practice to use it for all return
  # variable results in case the value could include one of those characters in
  # the future.  This method can be copied and reused between handlers.
  def escape(string)
    char_map = {'&'=>'&amp;', '>'=>'&gt;', '<'=>'&lt;', '"' => '&quot;'}
    # Globally replace characters based on the char_map variable
    string.to_s.gsub(/[&"><]/) { |special| char_map[special] } if string
  end

end
