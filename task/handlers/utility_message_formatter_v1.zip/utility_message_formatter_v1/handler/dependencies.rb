# -*- coding: utf-8 -*-
#

handler_path = File.expand_path(File.dirname(__FILE__))

unless defined?(Kramdown)
  # Load the Kramdown library unless it has already been loaded.
  # This library provides Markdown syntax support.
  $:.unshift File.join(handler_path, "vendor", "kramdown-1.13.2", "lib")
  # Require the library
  require "kramdown"
end
unless defined?(Concurrent)
  # Load the Concurrent library unless it has already been loaded.
  # This library is required by the tzinfo library.
  $:.unshift File.join(handler_path, "vendor", "concurrent-ruby-1.0.5-java", "lib")
  # Require the library
  require "concurrent"
end
unless defined?(TZInfo)
  # Load the TZInfo and TZInfo-Data libraries unless they have already been loaded.
  # These libraries provide TimeZone support.
  $:.unshift File.join(handler_path, "vendor", "tzinfo-2.0.0-pre1", "lib")
  $:.unshift File.join(handler_path, "vendor", "tzinfo-data-1.2018.5", "lib")
  # Require the libraries
  require "tzinfo"
  require "tzinfo/data"
end
unless defined?(Humanize::Byte)
  # Load the Humanize::Byte library unless it has already been loaded.
  $:.unshift File.join(handler_path, "vendor", "humanize-bytes", "lib")
  # Require the library
  require "humanize-bytes"
end


unless defined?(Kinetic::Commons)
  # Kinetic::Commons module
  module Kinetic
    module Commons

      # Escapes XML characters (&, ", <, and >) so that they themselves can be rendered in XML.
      #
      # Usage:  ::Kinetic::Commons.escape("<div>Hello World!</div>")
      #
      def self.escape(string)
        escape_map = {'&'=>'&amp;', '>'=>'&gt;', '<'=>'&lt;', '"' => '&quot;'}
        # Globally replace specified characters
        string.to_s.gsub(/[&"><]/) { |special| escape_map[special] } if string
      end

      # Generate HTML from Markdown using Github Flavored Markdown parser.
      #
      # Usage:  ::Kinetic::Commons.gfm_to_html("string")
      #
      # This is the same as calling
      #         ::Kinetic::Commons.md_to_html("string", :input => "GFM")
      #
      def self.gfm_to_html(string, options={})
        options[:input => "GFM"] unless options[:input]
        self.md_to_html(string, options)
      end

      # Generate HTML from Markdown.
      #
      # Usage:  ::Kinetic::Commons.md_to_html("string")
      #
      def self.md_to_html(string, options={})
        options[:auto_ids => false] unless options[:auto_ids]
        if string
          # ensure string is UTF-8 encoded
          string = string.encode("UTF-8")
          if options[:input]
            html = ::Kramdown::Document.new(string, options).to_html
          else
            html = ::Kramdown::Document.new(string, options.merge(:input => "kramdown")).to_html
          end
        end
      end

      def self.human_bytes(input, options={ decimal_digits: 1 })
        if self.is_numeric?(input)
          ::Humanize::Byte.new(input.to_i).human.to_s(options)
        else
          puts "Is not numeric: #{input}"
          input.to_s
        end
      end

      def self.is_numeric?(input)
        input.to_i.to_s == input.to_s || 
        input.to_f.to_s == input.to_s
      end

    end
  end
end
